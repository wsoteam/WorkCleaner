package app.magic.cleaner.boost;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.Log;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;


public class AdMobFullscreenManager {

    private static final int MAX_REQUEST_AD = 3;

    public enum AdMobState {
        Loaded,
        Loading,
        NoAd,
    }

    private int countRequestAd;

    private AdMobFullscreenDelegate delegate;
    public long extrasInt = -1;
    public boolean tryingShowDone = false;
    private AdMobState adMobState = AdMobState.Loading;
    private InterstitialAd mInterstitialAd;


    public AdMobFullscreenManager (Context context, @Nullable final AdMobFullscreenDelegate delegate) {
        mInterstitialAd = new InterstitialAd(context);
        configure(delegate);
    }

    private void configure (@Nullable AdMobFullscreenDelegate delegate) {
        mInterstitialAd.setAdUnitId("айдишник");
        //mInterstitialAd.setAdUnitId("");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        this.delegate = delegate;
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                Log.d("ExpressAppAdds", "onAdLoaded: ");
                countRequestAd= 0;
                adMobState = AdMobState.Loaded;
                if (AdMobFullscreenManager.this.delegate != null) {
                    AdMobFullscreenManager.this.delegate.ADLoaded();
                }
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                AdMobFullscreenManager.this.reloadAd();

                Log.d("ExpressAppAdds", "onAdFailedToLoad: " + errorCode);
            }

            @Override
            public void onAdOpened() {
                Log.d("ExpressAppAdds", "onAdOpened: ");
                // Code to be executed when the ad is displayed.
            }

            @Override
            public void onAdLeftApplication() {
                Log.d("ExpressAppAdds", "onAdLeftApplication: ");
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                Log.d("ExpressAppAdds", "onAdClosed: ");
                if (AdMobFullscreenManager.this.delegate != null) {
                    AdMobFullscreenManager.this.delegate.ADIsClosed();
                }

                // Code to be executed when when the interstitial ad is closed.
            }
        });
    }

    public boolean showAdd () {
        boolean b = false;
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
            b = true;
        } else {
            Log.d("TAG", "The interstitial wasn't loaded yet.");
        }
        return b;
    }

    public void completed() {
        tryingShowDone = true;
        if (adMobState == AdMobState.Loaded) {
            if (delegate != null) {
                delegate.ADLoaded();
            }
        } else if (adMobState == AdMobState.NoAd) {
            if (delegate != null) {
                delegate.ADIsClosed();
            }
        }

    }

    public void reloadAd () {
        countRequestAd++;
        if (countRequestAd == MAX_REQUEST_AD) {
            adMobState = AdMobState.NoAd;
            if (delegate != null) {
                delegate.ADIsClosed();
            }
            return;
        }

        if (mInterstitialAd.isLoaded()) {
            adMobState = AdMobState.Loaded;
            mInterstitialAd.show();
        } else if (!mInterstitialAd.isLoading()) {
            adMobState = AdMobState.Loading;
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        }
    }

    public interface AdMobFullscreenDelegate {
        void ADLoaded();
        void ADIsClosed();
    }


}


